<?php
	class EventoBlockController extends BlockController {
		
		var $pobj;
		
		protected $btDescription = "A simple testing block for developers.";
		protected $btName = "Evento";
		protected $btTable = 'btEvento';
		protected $btInterfaceWidth = "350";
		protected $btInterfaceHeight = "300";
		
		public function save($args) {
			$dtt = Loader::helper('form/date_time');
			$args['fecha']=$dtt->translate('fecha');
			parent::save($args);
		}

	}
	
?>