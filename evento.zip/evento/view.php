<?php echo 'FECHA:'.$fecha ?>
<?php echo 'Número:'.$numero ?>
