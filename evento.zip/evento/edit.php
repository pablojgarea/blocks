
<?php echo $form->label('fecha', 'Fecha');?>
<?php 

	$dtt = Loader::helper('form/date_time');


	echo $dtt->datetime('fecha', $fecha, false, true);

    echo '<div>'.$form->label('numero', 'Número');
    echo $form->text('numero',$numero).'</div>';

?>